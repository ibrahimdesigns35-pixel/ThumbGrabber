import type { Metadata } from 'next';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LandingSections from '@/components/LandingSections';
import Footer from '@/components/Footer';
import { BreadcrumbSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "Facebook Thumbnail Downloader - Download FB Video Covers",
    description: "Download Facebook video thumbnails and covers in high quality instantly. No signup. No tracking. 100% free and privacy-first.",
    keywords: ["facebook thumbnail downloader", "download facebook thumbnail", "fb video cover downloader", "grab facebook thumbnail"],
};

export default function FacebookDownloaderPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-20">
                {/* SEO Optimized Context */}
                <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        Facebook <span className="text-gradient">Thumbnail Downloader</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-12">
                        Need a Facebook video thumbnail?
                        Enter any Facebook video URL below to extract the high-quality cover image instantly.
                        Free, private, and fast.
                    </p>
                </div>

                <Hero
                    isSubPage={true}
                    title="Download Facebook Thumbnail"
                    subtitle="High Quality extraction"
                />

                <LandingSections />
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Facebook Thumbnail Downloader', url: '/facebook-thumbnail-downloader' }
                ]}
            />

            <Footer />
        </div>
    );
}
