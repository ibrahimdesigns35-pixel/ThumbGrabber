'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Zap, Github, Twitter, ShieldCheck, CheckCircle2, Heart } from 'lucide-react';
import Logo from './Logo';

/**
 * Footer Component - Production Ready
 */
export default function Footer() {
    const currentYear = new Date().getFullYear();

    return (
        <footer className="relative z-10 w-full pt-20 pb-10 px-4">
            <div className="max-w-7xl mx-auto">
                <div className="glass p-10 md:p-16 rounded-[3rem] border border-white/5 bg-slate-900/40">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-16">
                        <div className="md:col-span-5">
                            <Link href="/" className="mb-8 block">
                                <Logo />
                            </Link>
                            <p className="text-slate-400 text-lg mb-8 max-w-sm font-medium leading-relaxed">
                                The internet's most trusted, privacy-first media extraction tool.
                                <span className="text-white block mt-2">100% Free. No tracking. No cookies.</span>
                            </p>
                            <div className="flex items-center gap-4">
                                <motion.a
                                    whileHover={{ y: -3 }}
                                    href="https://github.com"
                                    target="_blank"
                                    className="w-10 h-10 glass rounded-xl flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                                >
                                    <Github className="w-5 h-5" />
                                </motion.a>
                                <motion.a
                                    whileHover={{ y: -3 }}
                                    href="https://twitter.com"
                                    target="_blank"
                                    className="w-10 h-10 glass rounded-xl flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                                >
                                    <Twitter className="w-5 h-5 fill-current" />
                                </motion.a>
                            </div>
                        </div>

                        {/* Links Columns */}
                        <div className="md:col-span-7 grid grid-cols-2 md:grid-cols-3 gap-8">
                            <div>
                                <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">Product</h4>
                                <ul className="space-y-4">
                                    <li><Link href="/#features" className="text-slate-400 hover:text-blue-400 text-sm font-bold transition-colors">Features</Link></li>
                                    <li><Link href="/#how-it-works" className="text-slate-400 hover:text-blue-400 text-sm font-bold transition-colors">How it works</Link></li>
                                    <li><Link href="/youtube-thumbnail-downloader" className="text-slate-400 hover:text-blue-400 text-sm font-bold transition-colors underline decoration-blue-500/30">YouTube HD</Link></li>
                                    <li className="group flex items-center gap-2 cursor-not-allowed">
                                        <span className="text-slate-600 text-sm font-bold">API Docs</span>
                                        <span className="px-1.5 py-0.5 bg-slate-800 text-slate-500 text-[8px] font-black uppercase rounded border border-white/5">Soon</span>
                                    </li>
                                </ul>
                            </div>
                            <div>
                                <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">Legal</h4>
                                <ul className="space-y-4">
                                    <li><Link href="/privacy" className="text-slate-400 hover:text-blue-400 text-sm font-bold transition-colors">Privacy Policy</Link></li>
                                    <li><Link href="/terms" className="text-slate-400 hover:text-blue-400 text-sm font-bold transition-colors">Terms of Service</Link></li>
                                    <li className="flex items-center gap-2 text-green-500/80 text-xs font-bold px-2 py-1 bg-green-500/5 rounded-md border border-green-500/10">
                                        <ShieldCheck className="w-3.5 h-3.5" />
                                        <span>Privacy-First</span>
                                    </li>
                                </ul>
                            </div>
                            <div className="col-span-2 md:col-span-1">
                                <h4 className="text-white font-bold mb-6 text-sm uppercase tracking-widest">Trust</h4>
                                <div className="space-y-4">
                                    <div className="flex items-center gap-2 text-slate-400 text-sm font-bold">
                                        <CheckCircle2 className="w-4 h-4 text-blue-500" />
                                        <span>Works on Mobile</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-slate-400 text-sm font-bold">
                                        <CheckCircle2 className="w-4 h-4 text-blue-500" />
                                        <span>1280x720 Support</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-slate-400 text-sm font-bold">
                                        <CheckCircle2 className="w-4 h-4 text-blue-500" />
                                        <span>100% Free Tool</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
                        <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">
                            © {currentYear} ThumbGrabber. No rights reserved — Open Source.
                        </p>
                        <div className="flex items-center gap-2 text-slate-500 text-sm font-medium">
                            <span>Built for creators with</span>
                            <Heart className="w-4 h-4 text-red-500 fill-red-500 inline-block animate-pulse" />
                            <span>Worldwide</span>
                        </div>
                        <p className="text-slate-600 text-[10px] max-w-[200px] text-center md:text-right leading-relaxed font-medium">
                            Disclaimer: This tool is for personal use only. We are not affiliated with YouTube or Meta.
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    );
}
