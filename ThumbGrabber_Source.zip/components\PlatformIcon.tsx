'use client';

import { Platform, PLATFORM_META, PlatformStatus } from '@/lib/platform-detector';
import { Youtube, Video, Music, Instagram, Linkedin, Twitter, Twitch, Facebook } from 'lucide-react';
import { LucideIcon } from 'lucide-react';

interface PlatformIconProps {
    platform: Platform;
    size?: 'sm' | 'md' | 'lg';
    showLabel?: boolean;
    showStatus?: boolean;
}

const PLATFORM_ICONS: Record<Platform, LucideIcon> = {
    youtube: Youtube,
    vimeo: Video,
    tiktok: Music,
    instagram: Instagram,
    linkedin: Linkedin,
    twitter: Twitter,
    twitch: Twitch,
    facebook: Facebook,
};

/**
 * Professional Platform Icon Component
 * Features:
 * - Consistent sizing (24-28px)
 * - Brand color on hover
 * - Disabled state for unsupported platforms
 * - "Coming Soon" badge
 * - Smooth animations
 */
export default function PlatformIcon({
    platform,
    size = 'md',
    showLabel = true,
    showStatus = true
}: PlatformIconProps) {
    const meta = PLATFORM_META[platform];
    const Icon = PLATFORM_ICONS[platform];

    if (!meta || !Icon) {
        return null;
    }

    const isDisabled = meta.status === 'unsupported';
    const isPartial = meta.status === 'partial';

    const sizeClasses = {
        sm: 'w-12 h-12',
        md: 'w-14 h-14',
        lg: 'w-16 h-16',
    };

    const iconSizes = {
        sm: 'w-6 h-6',   // 24px
        md: 'w-[28px] h-[28px]', // Exact 28px
        lg: 'w-8 h-8',   // 32px
    };

    return (
        <div className="flex flex-col items-center gap-2 group">
            {/* Icon Container */}
            <div
                className={`
                    ${sizeClasses[size]} 
                    rounded-xl 
                    border border-white/10 
                    bg-white/5
                    flex items-center justify-center
                    transition-all duration-300 ease-in-out
                    ${isDisabled
                        ? 'opacity-40 cursor-not-allowed'
                        : 'hover:scale-110 active:scale-95 cursor-pointer'
                    }
                    ${!isDisabled && 'hover:bg-white/10 hover:border-white/20 hover:shadow-[0_0_20px_rgba(255,255,255,0.05)]'}
                    relative
                `}
            >
                <Icon
                    className={`${iconSizes[size]} transition-all duration-300 group-hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]`}
                    style={{
                        color: isDisabled ? '#64748b' : meta.color,
                    }}
                />

                {/* Status Badge */}
                {showStatus && (isDisabled || isPartial) && (
                    <div
                        className={`
                            absolute -top-1 -right-1 
                            px-1.5 py-0.5 
                            rounded-full 
                            text-[8px] font-bold uppercase tracking-wider
                            ${isPartial
                                ? 'bg-yellow-500 text-black border border-yellow-400'
                                : 'bg-slate-700 text-slate-300 border border-slate-600'
                            }
                            shadow-lg
                        `}
                    >
                        {isPartial ? 'Limited' : 'Soon'}
                    </div>
                )}
            </div>

            {/* Label */}
            {showLabel && (
                <div className="text-center">
                    <p className={`
                        text-[11px] font-bold tracking-tight uppercase
                        ${isDisabled ? 'text-slate-600' : 'text-slate-400 group-hover:text-white'}
                        transition-colors duration-300
                    `}>
                        {meta.name}
                    </p>
                </div>
            )}
        </div>
    );
}
