import type { Metadata } from 'next';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LandingSections from '@/components/LandingSections';
import Footer from '@/components/Footer';
import { BreadcrumbSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "TikTok Thumbnail Downloader - Download TikTok Cover HD",
    description: "Download TikTok video thumbnails and covers in high quality instantly. No signup. No tracking. 100% free and privacy-first.",
    keywords: ["tiktok thumbnail downloader", "download tiktok thumbnail", "tiktok cover downloader", "grab tiktok thumbnail"],
};

export default function TikTokDownloaderPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-20">
                {/* SEO Optimized Context */}
                <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        TikTok <span className="text-gradient">Thumbnail Downloader</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-12">
                        Need to download a TikTok thumbnail or cover image?
                        Enter any TikTok video URL below to grab the high-quality thumbnail instantly.
                        Free, fast, and secure.
                    </p>
                </div>

                <Hero
                    isSubPage={true}
                    title="Download TikTok Thumbnail"
                    subtitle="High Quality Cover Extraction"
                />

                <section className="max-w-4xl mx-auto px-4 py-20 text-slate-300 space-y-12">
                    <div className="space-y-4">
                        <h2 className="text-3xl font-bold text-white">How to Download TikTok Thumbnails Free</h2>
                        <p>
                            ThumbGrabber provides the best tool for downloading TikTok video covers.
                            Whether you need them for design inspiration, reporting, or archival purposes,
                            our tool extracts the original cover image directly from the platform.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="glass p-8 rounded-3xl">
                            <h3 className="text-xl font-bold text-white mb-4">Fast & Reliable</h3>
                            <p className="text-sm text-slate-400">
                                Our extraction engine is optimized for TikTok's infrastructure, ensuring you get your images in seconds without any delay.
                            </p>
                        </div>
                        <div className="glass p-8 rounded-3xl">
                            <h3 className="text-xl font-bold text-white mb-4">No Watermarks</h3>
                            <p className="text-sm text-slate-400">
                                We extract the clean thumbnail image provided by TikTok, ensuring you get exactly what you see on the screen.
                            </p>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <h2 className="text-3xl font-bold text-white">Trustworthy TikTok Grabber</h2>
                        <p>
                            Unlike many shady websites, ThumbGrabber doesn't show intrusive ads or ask for personal information.
                            We prioritize your privacy and data security above all else.
                        </p>
                    </div>

                    <div className="space-y-6 pt-12 border-t border-white/5">
                        <h2 className="text-3xl font-bold text-white text-center mb-8">TikTok Thumbnail FAQ</h2>
                        <div className="space-y-8">
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Can I download TikTok covers on mobile?</h4>
                                <p className="text-sm">Yes! ThumbGrabber is fully responsive and works perfectly on all iOS and Android devices via any web browser.</p>
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Is there a limit to how many I can download?</h4>
                                <p className="text-sm">No. You can download as many TikTok thumbnails as you want. There are no daily or monthly limits.</p>
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Do I need to install an app?</h4>
                                <p className="text-sm">No installation is required. This is a web-based tool that runs entirely in your browser.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <LandingSections />
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'TikTok Thumbnail Downloader', url: '/tiktok-thumbnail-downloader' }
                ]}
            />

            <Footer />
        </div>
    );
}
