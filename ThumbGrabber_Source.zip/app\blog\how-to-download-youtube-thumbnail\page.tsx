import type { Metadata } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { BreadcrumbSchema, FAQSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "How to Download YouTube Thumbnails (Step-by-Step Guide)",
    description: "Learn how to download YouTube thumbnails in HD quality for free using our simple step-by-step guide. No software required.",
    keywords: ["how to download youtube thumbnail", "download youtube thumbnail guide", "youtube thumbnail download steps"],
};

export default function HowToPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-32 pb-20 px-4">
                <article className="max-w-4xl mx-auto prose prose-invert prose-blue">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-8">
                        How to <span className="text-gradient">Download YouTube Thumbnails</span>
                    </h1>

                    <p className="text-slate-400 text-lg mb-8">
                        Whether you're a designer looking for inspiration or a creator needing to archive your own work,
                        downloading a YouTube thumbnail is easier than you think.
                        Follow this simple guide to get HD thumbnails in seconds.
                    </p>

                    <h2 className="text-2xl font-bold text-white mb-6">Step 1: Copy the Video URL</h2>
                    <p>
                        Go to YouTube and find the video you want the thumbnail from.
                        Copy the URL from the browser's address bar or click the "Share" button and copy the link.
                    </p>

                    <h2 className="text-2xl font-bold text-white mb-6">Step 2: Paste into ThumbGrabber</h2>
                    <p>
                        Head over to our
                        <Link href="/youtube-thumbnail-downloader" className="text-blue-400 underline mx-1">
                            free downloader tool
                        </Link>
                        and paste the URL into the search box at the top of the page.
                    </p>

                    <h2 className="text-2xl font-bold text-white mb-6">Step 3: Extract and Save</h2>
                    <p>
                        Click the "Extract" button. Our system will immediately find all available resolutions.
                        Choose the "Max Resolution" (1280x720) and click the download button to save it to your device.
                    </p>

                    <div className="my-12 p-8 glass rounded-[2.5rem] border border-white/10 text-center">
                        <h3 className="text-2xl font-bold text-white mb-4">Why use ThumbGrabber?</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                                <div className="text-blue-400 font-bold text-xl mb-2">100% Free</div>
                                <p className="text-xs text-slate-500">No hidden costs or premium tiers.</p>
                            </div>
                            <div>
                                <div className="text-blue-400 font-bold text-xl mb-2">No Login</div>
                                <p className="text-xs text-slate-500">We don't need your data to work.</p>
                            </div>
                            <div>
                                <div className="text-blue-400 font-bold text-xl mb-2">HD Quality</div>
                                <p className="text-xs text-slate-500">Always get the max possible resolution.</p>
                            </div>
                        </div>
                    </div>

                    <h2 className="text-2xl font-bold text-white mb-8 text-center">Frequently Asked Questions</h2>
                    <div className="space-y-6">
                        <div className="glass p-6 rounded-2xl">
                            <h4 className="font-bold text-white mb-2">Does this work on mobile?</h4>
                            <p className="text-sm text-slate-400">Yes! Our website is optimized for all mobile browsers on iPhone and Android.</p>
                        </div>
                        <div className="glass p-6 rounded-2xl">
                            <h4 className="font-bold text-white mb-2">Can I download my own thumbnails?</h4>
                            <p className="text-sm text-slate-400">Absolutely. This is a great way to recover thumbnails if you've lost the original files.</p>
                        </div>
                    </div>
                </article>
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Blog', url: '/blog' },
                    { name: 'How to Download YouTube Thumbnail', url: '/blog/how-to-download-youtube-thumbnail' }
                ]}
            />
            <FAQSchema
                faqs={[
                    {
                        question: "Does this work on mobile devices?",
                        answer: "Yes! Our website is fully optimized for all mobile browsers on iPhone and Android."
                    },
                    {
                        question: "Can I download my own YouTube thumbnails?",
                        answer: "Absolutely. This is a great way to recover thumbnails if you've lost the original files."
                    }
                ]}
            />

            <Footer />
        </div>
    );
}
