import Header from "@/components/Header";
import Hero from "@/components/Hero";
import LandingSections from "@/components/LandingSections";
import Footer from "@/components/Footer";
import GlowEffect from "@/components/GlowEffect";

/**
 * ThumbGrabber Overhaul - Final Assembly
 * Premium. Privacy-First. Free.
 */
export default function Home() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />
            <GlowEffect />

            <main className="flex-grow">
                {/* Hero with Extraction & Interaction Logic */}
                <Hero />

                {/* Refined Landing Sections (Trust, How it Works) */}
                <LandingSections />
            </main>

            <Footer />
        </div>
    );
}
