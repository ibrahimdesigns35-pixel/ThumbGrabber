import type { Metadata } from 'next';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LandingSections from '@/components/LandingSections';
import Footer from '@/components/Footer';
import { BreadcrumbSchema, FAQSchema, HowToSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "Free YouTube Thumbnail Downloader (HD & Max Quality)",
    description: "Download YouTube thumbnails in original quality instantly. No signup. No tracking. 100% free and privacy-first.",
    keywords: ["youtube thumbnail downloader", "download youtube thumbnail", "youtube thumbnail grabber", "hd youtube thumbnail"],
};

export default function YouTubeDownloaderPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-20">
                {/* SEO Optimized Context */}
                <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        YouTube <span className="text-gradient">Thumbnail Downloader Free</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-12">
                        Download high-definition YouTube video thumbnails in original quality.
                        Enter any video URL below to grab the high-res image (1280x720 max) instantly.
                        Our tool is the best way to download youtube thumbnail hd images for free.
                    </p>
                </div>

                <Hero
                    isSubPage={true}
                    title="Download YouTube Thumbnail"
                    subtitle="HD & Original Resolution"
                />

                <section className="max-w-4xl mx-auto px-4 py-20 text-slate-300 space-y-12">
                    <div className="space-y-4">
                        <h2 className="text-3xl font-bold text-white">How to Download YouTube Thumbnail HD</h2>
                        <p>
                            ThumbGrabber provides the easiest way to download YouTube video thumbnails.
                            While many tools claim to offer 4K quality, YouTube's maximum thumbnail resolution is actually 1280x720 pixels (labeled as "maxresdefault").
                            Our tool ensures you always get this highest available version.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="glass p-8 rounded-3xl">
                            <h3 className="text-xl font-bold text-white mb-4">1280x720 Max Resolution</h3>
                            <p className="text-sm text-slate-400">
                                We always attempt to fetch the 720p version first. If the creator didn't upload a high-res image, we fall back to standard HD versions (640x480).
                            </p>
                        </div>
                        <div className="glass p-8 rounded-3xl">
                            <h3 className="text-xl font-bold text-white mb-4">Free & No Login Required</h3>
                            <p className="text-sm text-slate-400">
                                Unlike other tools, we don't ask for your email or credit card. ThumbGrabber is 100% free and will stay that way.
                            </p>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <h2 className="text-3xl font-bold text-white">Privacy-First Thumbnail Grabbing</h2>
                        <p>
                            We value your privacy. ThumbGrabber does not store your search history, IP address, or the URLs you paste.
                            Everything happens in your browser context, making it the most secure choice for creators.
                        </p>
                    </div>

                    <div className="space-y-6 pt-12 border-t border-white/5">
                        <h2 className="text-3xl font-bold text-white text-center mb-8">YouTube Thumbnail Downloader FAQ</h2>
                        <div className="space-y-8">
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Is it illegal to download YouTube thumbnails?</h4>
                                <p className="text-sm">Downloading thumbnails for personal use, design inspiration, or fair use in reporting is generally acceptable. However, always respect the original creator's copyright if you intend to reuse the image.</p>
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Can I get YouTube thumbnails in 4K?</h4>
                                <p className="text-sm">No. YouTube does not generate 4K (3840x2160) thumbnails. The highest quality provided by the platform is 1280x720 (High Definition).</p>
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Does this work for Shorts?</h4>
                                <p className="text-sm">Yes! Simply paste the URL of any YouTube Short, and our tool will extract the cover image just like a regular video.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <LandingSections />
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'YouTube Thumbnail Downloader', url: '/youtube-thumbnail-downloader' }
                ]}
            />
            <FAQSchema
                faqs={[
                    {
                        question: "Is it illegal to download YouTube thumbnails?",
                        answer: "Downloading thumbnails for personal use, design inspiration, or fair use in reporting is generally acceptable. However, always respect the original creator's copyright if you intend to reuse the image."
                    },
                    {
                        question: "Can I get YouTube thumbnails in 4K?",
                        answer: "No. YouTube does not generate 4K (3840x2160) thumbnails. The highest quality provided by the platform is 1280x720 (High Definition)."
                    },
                    {
                        question: "Does this work for Shorts?",
                        answer: "Yes! Simply paste the URL of any YouTube Short, and our tool will extract the cover image just like a regular video."
                    }
                ]}
            />
            <HowToSchema
                name="How to Download YouTube Thumbnail"
                description="Follow these steps to download any YouTube thumbnail in high resolution."
                steps={[
                    "Copy the YouTube video URL from your browser or app.",
                    "Paste the URL into the ThumbGrabber search box.",
                    "Click the Extract button to find available resolutions.",
                    "Download the HD thumbnail directly to your device."
                ]}
            />

            <Footer />
        </div>
    );
}
