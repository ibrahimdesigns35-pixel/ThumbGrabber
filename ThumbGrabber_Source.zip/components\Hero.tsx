'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Sparkles, ShieldCheck, Youtube, Music, Instagram, Facebook, Video, Twitter, Zap } from 'lucide-react';
import LogoIcon from './LogoIcon';
import PlatformIcon from './PlatformIcon';

interface HeroProps {
    title?: string;
    subtitle?: string;
    isSubPage?: boolean;
}

/**
 * Hero Component - Clean Minimalist Style
 */
export default function Hero({ title, subtitle, isSubPage = false }: HeroProps) {
    const [url, setUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [mediaData, setMediaData] = useState<MediaInfo | null>(null);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!url.trim() || loading) return;

        setError(null);
        setMediaData(null);

        const platformInfo = detectPlatform(url);

        if (!platformInfo) {
            setError('Please enter a valid video URL.');
            return;
        }

        setLoading(true);
        try {
            const info = await extractMedia(platformInfo.platform, platformInfo.id);

            if (!info) {
                setError(`Could not fetch media. Please ensure the link is public.`);
                return;
            }

            setMediaData(info);

            setTimeout(() => {
                document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' });
            }, 300);
        } catch (err) {
            console.error('Extraction error:', err);
            setError('An unexpected error occurred. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    if (!mounted) return null;

    return (
        <section className="relative w-full pt-32 pb-20 px-4 overflow-hidden">
            {/* Main Hero Container */}
            <div className="max-w-5xl mx-auto text-center relative z-10">
                {/* Brand Presence Logo - Ultra Premium Style */}
                {!isSubPage && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                        className="mb-16 flex justify-center"
                    >
                        <div className="relative group p-[1px] rounded-[2.5rem] bg-gradient-to-tr from-[#00F2FF]/20 via-[#3B82F6]/20 to-[#8B5CF6]/20 overflow-hidden">
                            <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur" />
                            <div className="glass p-10 rounded-[2.4rem] bg-slate-950/40 backdrop-blur-3xl border border-white/5 relative z-10">
                                <LogoIcon className="w-24 h-24" />
                            </div>
                        </div>
                    </motion.div>
                )}
                {/* Badge */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-white/10 text-blue-400 text-sm font-bold mb-8"
                >
                    <ShieldCheck className="w-4 h-4" />
                    <span>100% PRIVATE & SECURE</span>
                </motion.div>

                {/* Headline */}
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8, delay: 0.1 }}
                >
                    {isSubPage ? (
                        <h2 className="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-[1.1] tracking-tight">
                            {title || "Download Video Thumbnails"} <br />
                            <span className="text-gradient">{subtitle || "In Original Quality — Instantly"}</span>
                        </h2>
                    ) : (
                        <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-[1.1] tracking-tight">
                            {title || "Free YouTube Thumbnail Downloader"} <br />
                            <span className="text-gradient">{subtitle || "(HD & Max Quality)"}</span>
                        </h1>
                    )}
                </motion.div>

                {/* Subheadline */}
                <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 font-medium"
                >
                    Free. Fast. Privacy-First. No login. No tracking. <br />
                    <span className="text-slate-500 text-sm mt-2 block italic">“Privacy is our default, not an option.”</span>
                </motion.p>

                {/* Platform Icons Row */}
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8, delay: 0.5 }}
                    className="flex flex-wrap justify-center gap-8 mb-12"
                >
                    {['youtube', 'tiktok', 'instagram', 'facebook', 'twitter', 'vimeo'].map((p) => (
                        <PlatformIcon key={p} platform={p as any} size="md" showLabel={true} showStatus={true} />
                    ))}
                </motion.div>

                {/* Input Form */}
                <motion.form
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.6 }}
                    onSubmit={handleSubmit}
                    className="relative max-w-2xl mx-auto group"
                >
                    <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-600 rounded-[2rem] blur opacity-20 group-focus-within:opacity-40 transition duration-500" />
                    <div className="relative flex flex-col md:flex-row gap-3 p-2.5 glass-dark rounded-[1.8rem]">
                        <div className="flex-1 flex items-center px-5 gap-3 bg-white/5 rounded-2xl border border-white/5 focus-within:border-blue-500/50 transition-all">
                            <Search className="w-6 h-6 text-slate-500 group-focus-within:text-blue-400" />
                            <input
                                type="text"
                                placeholder="Paste video URL here..."
                                className="w-full py-4 bg-transparent border-none focus:ring-0 text-white placeholder:text-slate-600 font-medium outline-none"
                                value={url}
                                onChange={(e) => setUrl(e.target.value)}
                            />
                        </div>
                        <motion.button
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.97 }}
                            type="submit"
                            disabled={loading}
                            className="px-10 py-4 accent-gradient text-white font-bold rounded-2xl flex items-center justify-center gap-2 transition-all disabled:opacity-50 hover:shadow-[0_0_25px_rgba(59,130,246,0.5)] z-20"
                        >
                            {loading ? (
                                <motion.div
                                    animate={{ rotate: 360 }}
                                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                                    className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                                />
                            ) : (
                                <Zap className="w-5 h-5" />
                            )}
                            <span>{loading ? 'EXTRACTING...' : 'EXTRACT THUMBNAIL'}</span>
                        </motion.button>
                    </div>

                    <p className="mt-4 text-slate-500 text-xs font-medium">
                        Privacy-first. No downloads are stored.
                    </p>

                    <AnimatePresence>
                        {error && (
                            <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                className="mt-4 flex items-center gap-2 text-red-400 text-sm font-semibold justify-center overflow-hidden"
                            >
                                <Sparkles className="w-4 h-4" />
                                <span>{error}</span>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </motion.form>
            </div>

            {/* Results Section */}
            <AnimatePresence>
                {mediaData && (
                    <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        id="results"
                        className="max-w-7xl mx-auto mt-32"
                    >
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                            {/* Video Info Card */}
                            <div className="lg:col-span-4 glass p-6 rounded-[2rem] sticky top-24">
                                <div className="relative aspect-video rounded-xl overflow-hidden mb-6 group">
                                    <img
                                        src={mediaData.thumbnail_url}
                                        alt={mediaData.title}
                                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                                </div>
                                <h2 className="text-xl font-bold text-white mb-2 line-clamp-2">
                                    {mediaData.title}
                                </h2>
                                <p className="text-blue-400 font-bold mb-4">{mediaData.creator_name}</p>
                                <div className="flex items-center gap-2 p-3 bg-white/5 rounded-xl border border-white/5 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                                    <Zap className="w-4 h-4 text-blue-400" />
                                    <span>{mediaData.thumbnails.length} VERSIONS FOUND</span>
                                </div>
                            </div>

                            {/* Thumbnails Grid */}
                            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                                {mediaData.thumbnails.map((thumb, index) => (
                                    <ThumbnailCard
                                        key={`${thumb.url}-${index}`}
                                        url={thumb.url}
                                        resolution={thumb.resolution}
                                        videoTitle={mediaData.title}
                                        channelName={mediaData.creator_name}
                                        platform={mediaData.platform}
                                    />
                                ))}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </section>
    );
}
