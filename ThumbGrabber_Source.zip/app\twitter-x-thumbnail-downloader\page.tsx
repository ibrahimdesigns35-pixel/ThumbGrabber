import type { Metadata } from 'next';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LandingSections from '@/components/LandingSections';
import Footer from '@/components/Footer';
import { BreadcrumbSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "Twitter (X) Thumbnail Downloader - Download X Video Covers",
    description: "Download Twitter (X) video thumbnails and covers in high quality instantly. No signup. No tracking. 100% free and privacy-first.",
    keywords: ["twitter thumbnail downloader", "x thumbnail downloader", "download twitter video cover", "grab x thumbnail"],
};

export default function TwitterDownloaderPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-20">
                {/* SEO Optimized Context */}
                <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        Twitter (X) <span className="text-gradient">Thumbnail Downloader</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-12">
                        Extract and download thumbnails from Twitter (X) videos instantly.
                        Enter the tweet URL below to grab the high-res image.
                    </p>
                </div>

                <Hero
                    isSubPage={true}
                    title="Download Twitter(X) Thumbnail"
                    subtitle="Instant High Performance"
                />

                <LandingSections />
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Twitter (X) Thumbnail Downloader', url: '/twitter-x-thumbnail-downloader' }
                ]}
            />

            <Footer />
        </div>
    );
}
