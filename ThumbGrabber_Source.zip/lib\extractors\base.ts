/**
 * Base Extractor Interface
 * Defines the contract for all platform-specific extractors
 */

export interface ThumbnailInfo {
    url: string;
    resolution: string;
    available: boolean;
}

export interface MediaInfo {
    platform: string;
    title: string;
    creator_name: string;
    thumbnail_url: string; // Primary thumbnail
    thumbnails: ThumbnailInfo[];
}

export interface Extractor {
    /**
     * Extracts media information from platform
     * @param id - Platform-specific media ID
     * @returns MediaInfo object or null if extraction fails
     */
    extract(id: string): Promise<MediaInfo | null>;
}

/**
 * Base error class for extractor errors
 */
export class ExtractorError extends Error {
    constructor(
        message: string,
        public platform: string,
        public code?: string
    ) {
        super(message);
        this.name = 'ExtractorError';
    }
}

/**
 * Utility to check if a URL returns 404
 * Used for validating thumbnail availability
 */
export async function checkUrlAvailability(url: string): Promise<boolean> {
    try {
        const response = await fetch(url, { method: 'HEAD' });
        return response.ok;
    } catch {
        return false;
    }
}

/**
 * Utility to fetch with timeout
 */
export async function fetchWithTimeout(
    url: string,
    timeout: number = 10000
): Promise<Response> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
        const response = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);
        return response;
    } catch (error) {
        clearTimeout(timeoutId);
        throw error;
    }
}
