'use client';

import React from 'react';

interface LogoIconProps {
    className?: string;
}

/**
 * Ultra-Premium LogoIcon - Abstract Geometric Shards
 * Silicon-Valley-grade aesthetic inspired by Linear/Vercel.
 */
export default function LogoIcon({ className = "w-10 h-10" }: LogoIconProps) {
    return (
        <svg
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={className}
        >
            {/* Background Abstract Geometry */}
            <path
                d="M20 20 L80 20 L80 80 L20 80 Z"
                fill="url(#ultra-gradient)"
                className="opacity-10"
            />

            {/* Interlocking Shard 1 (Top-Left Capture) */}
            <path
                d="M15 45V25C15 19.4772 19.4772 15 25 15H45L35 35L15 45Z"
                fill="url(#ultra-gradient)"
                filter="url(#subtle-glow)"
            />

            {/* Interlocking Shard 2 (Bottom-Right Capture) */}
            <path
                d="M85 55V75C85 80.5228 80.5228 85 75 85H55L65 65L85 55Z"
                fill="url(#ultra-gradient)"
                filter="url(#subtle-glow)"
            />

            {/* Central Precision Point (The "Extraction" Core) */}
            <rect
                x="44"
                y="44"
                width="12"
                height="12"
                rx="3"
                fill="white"
                className="animate-pulse shadow-[0_0_10px_white]"
            />

            {/* Geometric Accent Lines */}
            <path d="M45 15L35 35H15" stroke="white" strokeWidth="0.5" className="opacity-30" />
            <path d="M55 85L65 65H85" stroke="white" strokeWidth="0.5" className="opacity-30" />

            {/* Gradient Definitions */}
            <defs>
                <linearGradient id="ultra-gradient" x1="15" y1="15" x2="85" y2="85" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#00F2FF" /> {/* Neon Cyan */}
                    <stop offset="0.5" stopColor="#3B82F6" /> {/* Electric Blue */}
                    <stop offset="1" stopColor="#8B5CF6" /> {/* Violet */}
                </linearGradient>

                <filter id="subtle-glow" x="0" y="0" width="100" height="100">
                    <feGaussianBlur stdDeviation="2" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
            </defs>
        </svg>
    );
}
