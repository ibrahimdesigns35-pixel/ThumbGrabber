'use client';

import React from 'react';
import { motion } from 'framer-motion';
import {
    ShieldCheck,
    Zap,
    Globe,
    Download,
    Copy,
    Play,
    CheckCircle2,
    Star,
    Smartphone,
    Laptop
} from 'lucide-react';

const WHY_CHOOSE_CARDS = [
    {
        Icon: Zap,
        title: "High Quality Extraction",
        description: "Get thumbnails in original resolution — up to 1280x720 for YouTube with zero compression and max quality.",
    },
    {
        Icon: Globe,
        title: "Multi-Platform Support",
        description: "Download thumbnails from YouTube, TikTok, Instagram, Facebook, Vimeo and more with ease.",
    },
    {
        Icon: Smartphone,
        title: "Lightning Fast",
        description: "Proprietary extraction engine gets your thumbnails in less than 2 seconds for high-speed grabbing.",
    },
    {
        Icon: ShieldCheck,
        title: "Privacy First (No Data Stored)",
        description: "No URLs saved. No tracking. No cookies. 100% private thumbnail downloading without login.",
    }
];

const STEPS = [
    { number: "01", Icon: Copy, text: "Copy video URL" },
    { number: "02", Icon: Laptop, text: "Paste it into the tool" },
    { number: "03", Icon: Zap, text: "Click “Extract”" },
    { number: "04", Icon: Download, text: "Download instantly" }
];

const TRUST_SIGNALS = [
    "Free Forever", "No Login Required", "No Data Stored", "Mobile Friendly"
];

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1
        }
    }
};

const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
        opacity: 1,
        y: 0,
        transition: { duration: 0.5 }
    }
};

export default function LandingSections() {
    return (
        <div className="w-full">
            {/* Why Choose Section */}
            <section id="features" className="max-w-7xl mx-auto py-32 px-4">
                <motion.div
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-100px" }}
                    variants={containerVariants}
                    className="text-center mb-20"
                >
                    <motion.h2 variants={itemVariants} className="text-4xl md:text-5xl font-bold text-white mb-6">
                        Why Choose This <span className="text-gradient">Thumbnail Downloader?</span>
                    </motion.h2>
                    <motion.p variants={itemVariants} className="text-slate-400 max-w-2xl mx-auto font-medium">
                        The world's most advanced, privacy-first media extraction tool for creators and designers.
                    </motion.p>
                </motion.div>

                <motion.div
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-100px" }}
                    variants={containerVariants}
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
                >
                    {WHY_CHOOSE_CARDS.map((card, i) => (
                        <motion.div
                            key={`feature-${i}`}
                            variants={itemVariants}
                            whileHover={{ y: -10 }}
                            className="glass p-8 rounded-[2.5rem] group relative overflow-hidden"
                        >
                            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                            <div className="relative z-10">
                                <div className="w-14 h-14 accent-gradient rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_20px_rgba(59,130,246,0.3)]">
                                    <card.Icon className="w-7 h-7 text-white fill-white" />
                                </div>
                                <h3 className="text-xl font-bold text-white mb-3">{card.title}</h3>
                                <p className="text-slate-400 text-sm leading-relaxed">{card.description}</p>
                            </div>
                        </motion.div>
                    ))}
                </motion.div>
            </section>

            {/* How It Works Section */}
            <section id="how-it-works" className="max-w-7xl mx-auto py-32 px-4 border-y border-white/5 relative">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.7 }}
                    >
                        <h2 className="text-4xl md:text-5xl font-bold text-white mb-8 leading-tight">
                            Start Extracting in <br />
                            <span className="text-gradient">4 Simple Steps</span>
                        </h2>
                        <div className="grid grid-cols-1 gap-6">
                            {STEPS.map((step, i) => (
                                <motion.div
                                    key={`step-${i}`}
                                    whileHover={{ x: 10 }}
                                    className="flex items-center gap-6 p-4 glass rounded-2xl border border-white/5 bg-slate-900/40"
                                >
                                    <div className="text-2xl font-black text-blue-500/30 font-poppins">{step.number}</div>
                                    <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center">
                                        <step.Icon className="w-7 h-7 text-blue-400" />
                                    </div>
                                    <p className="text-white font-bold">{step.text}</p>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, x: 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.7 }}
                        className="relative"
                    >
                        <div className="absolute -inset-4 accent-gradient rounded-[3rem] blur-3xl opacity-20 animate-pulse" />
                        <div className="relative glass p-1 rounded-[3rem] overflow-hidden bg-slate-950">
                            <div className="rounded-[2.8rem] p-12 aspect-square flex flex-col items-center justify-center text-center">
                                <div className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center mb-8 relative">
                                    <Play className="w-10 h-10 text-blue-500 fill-blue-500 relative z-10" />
                                    <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-ping" />
                                </div>
                                <h3 className="text-2xl font-bold text-white mb-4">No Account Needed</h3>
                                <p className="text-slate-400 mb-8 max-w-xs font-medium">
                                    ThumbGrabber is built on trust and privacy. Just paste your link and you are ready to go.
                                </p>
                                <motion.button
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                    onClick={() => {
                                        if (typeof window !== 'undefined') {
                                            window.scrollTo({ top: 0, behavior: 'smooth' });
                                        }
                                    }}
                                    className="px-8 py-4 accent-gradient text-white font-bold rounded-2xl shadow-[0_0_20px_rgba(59,130,246,0.3)]"
                                >
                                    GET STARTED NOW
                                </motion.button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* Trust Signals & Stats */}
            <section className="max-w-7xl mx-auto py-32 px-4 text-center">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="flex flex-wrap justify-center gap-6 md:gap-12 mb-16"
                >
                    {TRUST_SIGNALS.map((signal, i) => (
                        <div key={`trust-${i}`} className="flex items-center gap-3 glass px-5 py-3 rounded-full border border-white/5">
                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                            <span className="text-md font-bold text-slate-300">{signal}</span>
                        </div>
                    ))}
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="inline-block glass px-10 py-6 rounded-[2.5rem] border border-white/10 bg-slate-900/40"
                >
                    <div className="flex flex-col md:flex-row items-center gap-6">
                        <div className="flex -space-x-4">
                            {[1, 2, 3, 4].map(i => (
                                <div key={`avatar-${i}`} className="w-12 h-12 rounded-full border-4 border-slate-900 bg-slate-800 overflow-hidden shadow-lg">
                                    <img src={`https://i.pravatar.cc/150?u=${i}`} alt="user avatar" />
                                </div>
                            ))}
                        </div>
                        <div className="text-center md:text-left">
                            <div className="flex justify-center md:justify-start text-yellow-500 mb-1">
                                {[1, 2, 3, 4, 5].map(i => <Star key={`star-${i}`} className="w-4 h-4 fill-current" />)}
                            </div>
                            <p className="text-white font-bold text-sm tracking-tight">Used by 15,000+ creators worldwide</p>
                            <p className="text-slate-500 text-xs font-medium">Privacy-First • High Performance • 100% Free</p>
                        </div>
                    </div>
                </motion.div>
            </section>
        </div>
    );
}
