/**
 * Twitch Extractor
 * Extracts stream/video thumbnails and metadata from Twitch
 */

import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout } from './base';

export class TwitchExtractor implements Extractor {
    async extract(id: string): Promise<MediaInfo | null> {
        try {
            // Twitch has different URL patterns for videos and channels
            const isVideo = /^\d+$/.test(id);

            if (isVideo) {
                return this.extractVideo(id);
            } else {
                return this.extractChannel(id);
            }
        } catch (error) {
            console.error('Twitch extraction error:', error);
            return null;
        }
    }

    private async extractVideo(videoId: string): Promise<MediaInfo | null> {
        // Twitch video thumbnail format
        const thumbnails = this.generateVideoThumbnails(videoId);

        return {
            platform: 'twitch',
            title: 'Twitch Video',
            creator_name: 'Twitch User',
            thumbnail_url: thumbnails[0].url,
            thumbnails,
        };
    }

    private async extractChannel(channelName: string): Promise<MediaInfo | null> {
        // Twitch stream thumbnail format
        const thumbnails = this.generateStreamThumbnails(channelName);

        return {
            platform: 'twitch',
            title: `${channelName}'s Stream`,
            creator_name: channelName,
            thumbnail_url: thumbnails[0].url,
            thumbnails,
        };
    }

    private generateVideoThumbnails(videoId: string): ThumbnailInfo[] {
        // Twitch video thumbnail format
        const sizes = [
            { width: 1920, height: 1080, resolution: 'Full HD (1920x1080)' },
            { width: 1280, height: 720, resolution: 'HD (1280x720)' },
            { width: 640, height: 360, resolution: 'SD (640x360)' },
            { width: 320, height: 180, resolution: 'Small (320x180)' },
        ];

        return sizes.map(size => ({
            url: `https://static-cdn.jtvnw.net/cf_vods/d2nvs31859zcd8/thumbnails/${videoId}-${size.width}x${size.height}.jpg`,
            resolution: size.resolution,
            available: true,
        }));
    }

    private generateStreamThumbnails(channelName: string): ThumbnailInfo[] {
        // Twitch stream preview format
        const sizes = [
            { width: 1920, height: 1080, resolution: 'Full HD (1920x1080)' },
            { width: 1280, height: 720, resolution: 'HD (1280x720)' },
            { width: 640, height: 360, resolution: 'SD (640x360)' },
            { width: 320, height: 180, resolution: 'Small (320x180)' },
        ];

        return sizes.map(size => ({
            url: `https://static-cdn.jtvnw.net/previews-ttv/live_user_${channelName.toLowerCase()}-${size.width}x${size.height}.jpg`,
            resolution: size.resolution,
            available: true,
        }));
    }
}

export const twitchExtractor = new TwitchExtractor();
