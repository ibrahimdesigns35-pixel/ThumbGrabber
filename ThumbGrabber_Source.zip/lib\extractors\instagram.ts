/**
 * Instagram Extractor
 * Extracts post/video thumbnails and metadata from Instagram
 */

import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout } from './base';

interface InstagramOEmbedResponse {
    title?: string;
    author_name: string;
    thumbnail_url: string;
}

export class InstagramExtractor implements Extractor {
    async extract(postId: string): Promise<MediaInfo | null> {
        try {
            // Instagram oEmbed endpoint
            const url = `https://www.instagram.com/p/${postId}/`;

            const response = await fetchWithTimeout(
                `https://graph.facebook.com/v12.0/instagram_oembed?url=${encodeURIComponent(url)}&access_token=`
            );

            // Note: Instagram oEmbed may require access token for some requests
            // Fallback to basic extraction if oEmbed fails
            if (!response.ok) {
                return this.fallbackExtraction(postId);
            }

            const data: InstagramOEmbedResponse = await response.json();

            const thumbnails: ThumbnailInfo[] = [
                {
                    url: data.thumbnail_url,
                    resolution: 'Instagram Post',
                    available: true,
                },
            ];

            return {
                platform: 'instagram',
                title: data.title || 'Instagram Post',
                creator_name: data.author_name,
                thumbnail_url: data.thumbnail_url,
                thumbnails,
            };
        } catch (error) {
            console.error('Instagram extraction error:', error);
            return this.fallbackExtraction(postId);
        }
    }

    private async fallbackExtraction(postId: string): Promise<MediaInfo | null> {
        try {
            // Alternative: Use Instagram's public JSON endpoint
            const response = await fetchWithTimeout(
                `https://www.instagram.com/p/${postId}/?__a=1&__d=dis`
            );

            if (!response.ok) {
                throw new ExtractorError('Failed to fetch Instagram post', 'instagram', 'FETCH_FAILED');
            }

            const data = await response.json();
            const media = data?.items?.[0] || data?.graphql?.shortcode_media;

            if (!media) {
                throw new ExtractorError('No media found', 'instagram', 'NO_MEDIA');
            }

            const thumbnailUrl = media.display_url || media.thumbnail_src;
            const username = media.owner?.username || 'Instagram User';

            const thumbnails: ThumbnailInfo[] = [
                {
                    url: thumbnailUrl,
                    resolution: 'Instagram Post',
                    available: true,
                },
            ];

            return {
                platform: 'instagram',
                title: media.edge_media_to_caption?.edges?.[0]?.node?.text || 'Instagram Post',
                creator_name: username,
                thumbnail_url: thumbnailUrl,
                thumbnails,
            };
        } catch (error) {
            console.error('Instagram fallback extraction error:', error);
            return null;
        }
    }
}

export const instagramExtractor = new InstagramExtractor();
