import type { Metadata, Viewport } from "next";
import { Inter, Poppins } from 'next/font/google';
import "./globals.css";
import { SoftwareApplicationSchema } from "@/components/SEOComponents";

const inter = Inter({
    subsets: ['latin'],
    variable: '--font-inter',
    display: 'swap',
});

const poppins = Poppins({
    weight: ['600', '700', '800'],
    subsets: ['latin'],
    variable: '--font-poppins',
    display: 'swap',
});

export const viewport: Viewport = {
    themeColor: '#0f172a',
    width: 'device-width',
    initialScale: 1,
};

export const metadata: Metadata = {
    title: {
        default: "ThumbGrabber | Free YouTube Thumbnail Downloader (HD & Max Quality)",
        template: "%s | ThumbGrabber"
    },
    description: "Download high-quality YouTube thumbnails in original resolution (1280x720) instantly. 100% free, no login, no tracking, and privacy-first.",
    keywords: ["youtube thumbnail downloader", "hd thumbnails", "grab youtube image", "thumbgrabber", "download youtube thumbnail", "vimeo thumbnail downloader"],
    authors: [{ name: "ThumbGrabber Team" }],
    metadataBase: new URL('https://thumbgrabber-official.vercel.app'), // Placeholder production URL
    openGraph: {
        title: "ThumbGrabber | HD YouTube Thumbnail Downloader",
        description: "The internet's most trusted, privacy-first media extraction tool. 100% Free.",
        url: 'https://thumbgrabber-official.vercel.app',
        siteName: 'ThumbGrabber',
        images: [
            {
                url: '/og-image.png',
                width: 1200,
                height: 630,
                alt: 'ThumbGrabber - High Quality Thumbnail Downloader',
            },
        ],
        locale: 'en_US',
        type: 'website',
    },
    twitter: {
        card: 'summary_large_image',
        title: "ThumbGrabber | HD YouTube Thumbnail Downloader",
        description: "Download high-quality YouTube thumbnails in seconds. No signup required.",
        images: ['/og-image.png'],
        creator: '@thumbgrabber',
    },
    robots: {
        index: true,
        follow: true,
    },
    alternates: {
        canonical: 'https://thumbgrabber-official.vercel.app',
    },
    icons: {
        icon: '/logo.svg',
        apple: '/logo.svg',
    },
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="en" className={`dark ${inter.variable} ${poppins.variable} selection-glow`}>
            <body className="antialiased bg-slate-950 min-h-screen">
                {/* Premium Background Layer */}
                <div className="noise-overlay" />
                <div className="blob-container">
                    <div className="blob blob-blue" />
                    <div className="blob blob-purple" />
                </div>

                {/* Main Content */}
                <main className="relative z-10 flex flex-col min-h-screen">
                    {children}
                </main>

                {/* Global Structured Data */}
                <SoftwareApplicationSchema />
            </body>
        </html>
    );
}
