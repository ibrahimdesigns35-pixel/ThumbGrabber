/**
 * Facebook Extractor
 * Extracts video thumbnails and metadata from Facebook
 */

import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout } from './base';

interface FacebookOEmbedResponse {
    author_name: string;
    author_url: string;
    provider_name: string;
    title?: string;
}

export class FacebookExtractor implements Extractor {
    async extract(videoId: string): Promise<MediaInfo | null> {
        try {
            // Facebook oEmbed endpoint
            const url = `https://www.facebook.com/watch/?v=${videoId}`;

            const response = await fetchWithTimeout(
                `https://www.facebook.com/plugins/video/oembed.json/?url=${encodeURIComponent(url)}`
            );

            if (!response.ok) {
                throw new ExtractorError('Failed to fetch Facebook video', 'facebook', 'FETCH_FAILED');
            }

            const data: FacebookOEmbedResponse = await response.json();

            // Facebook video thumbnail format
            const thumbnailUrl = `https://graph.facebook.com/${videoId}/picture`;

            const thumbnails: ThumbnailInfo[] = [
                {
                    url: thumbnailUrl,
                    resolution: 'Facebook Video Thumbnail',
                    available: true,
                },
            ];

            return {
                platform: 'facebook',
                title: data.title || 'Facebook Video',
                creator_name: data.author_name || 'Facebook User',
                thumbnail_url: thumbnailUrl,
                thumbnails,
            };
        } catch (error) {
            console.error('Facebook extraction error:', error);
            return null;
        }
    }
}

export const facebookExtractor = new FacebookExtractor();
