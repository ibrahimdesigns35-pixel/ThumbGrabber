/**
 * Vimeo Extractor
 * Extracts video thumbnails and metadata from Vimeo
 */

import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout } from './base';

interface VimeoOEmbedResponse {
    title: string;
    author_name: string;
    thumbnail_url: string;
    thumbnail_width: number;
    thumbnail_height: number;
}

export class VimeoExtractor implements Extractor {
    async extract(videoId: string): Promise<MediaInfo | null> {
        try {
            const url = `https://vimeo.com/${videoId}`;
            const response = await fetchWithTimeout(
                `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`
            );

            if (!response.ok) {
                throw new ExtractorError('Failed to fetch Vimeo video', 'vimeo', 'FETCH_FAILED');
            }

            const data: VimeoOEmbedResponse = await response.json();

            // Vimeo provides different thumbnail sizes
            const thumbnails = this.generateThumbnailVariants(data.thumbnail_url);

            return {
                platform: 'vimeo',
                title: data.title,
                creator_name: data.author_name,
                thumbnail_url: data.thumbnail_url,
                thumbnails,
            };
        } catch (error) {
            if (error instanceof ExtractorError) {
                throw error;
            }
            console.error('Vimeo extraction error:', error);
            return null;
        }
    }

    private generateThumbnailVariants(baseUrl: string): ThumbnailInfo[] {
        // Vimeo thumbnail URL format: https://i.vimeocdn.com/video/{id}_{width}x{height}.jpg
        // We can request different sizes by modifying the URL
        const sizes = [
            { width: 1280, height: 720, resolution: 'HD (1280x720)' },
            { width: 960, height: 540, resolution: 'Large (960x540)' },
            { width: 640, height: 360, resolution: 'Medium (640x360)' },
            { width: 480, height: 270, resolution: 'Small (480x270)' },
        ];

        return sizes.map(size => {
            // Replace the size in the URL
            const url = baseUrl.replace(/_\d+x\d+/, `_${size.width}x${size.height}`);
            return {
                url,
                resolution: size.resolution,
                available: true, // Vimeo thumbnails are generally always available
            };
        });
    }
}

export const vimeoExtractor = new VimeoExtractor();
