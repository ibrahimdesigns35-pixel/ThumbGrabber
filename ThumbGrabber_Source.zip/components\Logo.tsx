'use client';

import { motion } from 'framer-motion';
import LogoIcon from './LogoIcon';

/**
 * Ultra-Premium Logo Component - Custom Abstract Identity
 */
export default function Logo() {
    return (
        <motion.div
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex items-center gap-4 cursor-pointer"
        >
            <div className="relative">
                <LogoIcon className="w-10 h-10" />
                <motion.div
                    animate={{ opacity: [0.1, 0.3, 0.1] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="absolute inset-0 bg-blue-500 blur-2xl rounded-full -z-10"
                />
            </div>

            {/* Wordmark: Premium Silicon Valley Aesthetic */}
            <div className="flex flex-col">
                <span className="text-2xl font-bold tracking-[-0.03em] text-white leading-none">
                    ThumbGrabber
                </span>
                <span className="text-[10px] font-black tracking-[0.2em] text-blue-400 uppercase opacity-60 mt-1">
                    Media Extraction
                </span>
            </div>
        </motion.div>
    );
}
