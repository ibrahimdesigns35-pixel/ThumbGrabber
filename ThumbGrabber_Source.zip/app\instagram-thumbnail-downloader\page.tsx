import type { Metadata } from 'next';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LandingSections from '@/components/LandingSections';
import Footer from '@/components/Footer';
import { BreadcrumbSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "Instagram Thumbnail Downloader - Download IG Video Covers",
    description: "Download Instagram video thumbnails and covers in high quality instantly. No signup. No tracking. 100% free and privacy-first.",
    keywords: ["instagram thumbnail downloader", "download instagram thumbnail", "ig video cover downloader", "grab instagram thumbnail"],
};

export default function InstagramDownloaderPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-20">
                {/* SEO Optimized Context */}
                <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        Instagram <span className="text-gradient">Thumbnail Downloader</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-12">
                        Download Instagram thumbnails, Reels covers, and video images for free.
                        Enter any IG video URL below to grab the high-res image instantly.
                    </p>
                </div>

                <Hero
                    isSubPage={true}
                    title="Download Instagram Thumbnail"
                    subtitle="HD Reels & Video Covers"
                />

                <section className="max-w-4xl mx-auto px-4 py-20 text-slate-300 space-y-12">
                    <div className="space-y-4">
                        <h2 className="text-3xl font-bold text-white">Download Instagram Video Covers in High Quality</h2>
                        <p>
                            ThumbGrabber is the ultimate tool for Instagram creators.
                            We extract the highest resolution cover images from Reels, IGTV, and regular video posts,
                            perfect for mood boards and design projects.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="glass p-8 rounded-3xl">
                            <h3 className="text-xl font-bold text-white mb-4">Reels & IGTV Support</h3>
                            <p className="text-sm text-slate-400">
                                Whether it's a short Reel or a long IGTV video, our tool handles both with ease.
                            </p>
                        </div>
                        <div className="glass p-8 rounded-3xl">
                            <h3 className="text-xl font-bold text-white mb-4">Instant Downloads</h3>
                            <p className="text-sm text-slate-400">
                                Just click download and save the image to your device instantly. No redirection, no nonsense.
                            </p>
                        </div>
                    </div>

                    <div className="space-y-6 pt-12 border-t border-white/5">
                        <h2 className="text-3xl font-bold text-white text-center mb-8">Instagram Thumbnail FAQ</h2>
                        <div className="space-y-8">
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Can I download covers from private accounts?</h4>
                                <p className="text-sm">No. Due to privacy restrictions, we can only extract thumbnails from public Instagram accounts.</p>
                            </div>
                            <div>
                                <h4 className="text-lg font-bold text-blue-400 mb-2">Is this tool free to use?</h4>
                                <p className="text-sm">Yes, ThumbGrabber is 100% free and does not require any registration or payment.</p>
                            </div>
                        </div>
                    </div>
                </section>

                <LandingSections />
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Instagram Thumbnail Downloader', url: '/instagram-thumbnail-downloader' }
                ]}
            />

            <Footer />
        </div>
    );
}
