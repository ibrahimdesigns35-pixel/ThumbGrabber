export type Platform =
    | 'youtube'
    | 'vimeo'
    | 'tiktok'
    | 'instagram'
    | 'linkedin'
    | 'twitter'
    | 'twitch'
    | 'facebook';

export interface PlatformConfig {
    name: string;
    status: 'supported' | 'unsupported' | 'partial';
    color: string;
    icon: string;
    description: string;
}

export interface PlatformInfo {
    platform: Platform;
    id: string;
}

/**
 * PLATFORM_META - Honesty & Clarity
 */
export const PLATFORM_META: Record<Platform, PlatformConfig> = {
    youtube: {
        name: 'YouTube',
        status: 'supported',
        color: '#FF0000',
        icon: 'youtube',
        description: 'Original quality (up to 720p)'
    },
    vimeo: {
        name: 'Vimeo',
        status: 'supported',
        color: '#1AB7EA',
        icon: 'video',
        description: 'High-quality extraction'
    },
    tiktok: {
        name: 'TikTok',
        status: 'unsupported',
        color: '#000000',
        icon: 'music',
        description: 'Coming soon'
    },
    instagram: {
        name: 'Instagram',
        status: 'unsupported',
        color: '#E4405F',
        icon: 'instagram',
        description: 'Coming soon'
    },
    facebook: {
        name: 'Facebook',
        status: 'unsupported',
        color: '#1877F2',
        icon: 'facebook',
        description: 'Under development'
    },
    twitter: {
        name: 'X / Twitter',
        status: 'unsupported',
        color: '#000000',
        icon: 'twitter',
        description: 'Coming soon'
    },
    linkedin: {
        name: 'LinkedIn',
        status: 'unsupported',
        color: '#0A66C2',
        icon: 'linkedin',
        description: 'Planned'
    },
    twitch: {
        name: 'Twitch',
        status: 'unsupported',
        color: '#9146FF',
        icon: 'twitch',
        description: 'Planned'
    }
};

const PLATFORM_PATTERNS: Record<Platform, RegExp[]> = {
    youtube: [
        /youtube\.com\/watch\?v=([^&]+)/,
        /youtube\.com\/shorts\/([^?]+)/,
        /youtu\.be\/([^?]+)/,
        /youtube\.com\/embed\/([^?]+)/,
        /youtube\.com\/v\/([^?]+)/,
    ],
    vimeo: [
        /vimeo\.com\/(\d+)/,
        /vimeo\.com\/groups\/[^/]+\/videos\/(\d+)/,
        /vimeo\.com\/channels\/[^/]+\/(\d+)/,
    ],
    tiktok: [],
    instagram: [],
    facebook: [],
    twitter: [],
    linkedin: [],
    twitch: [],
};

export function detectPlatform(url: string): PlatformInfo | null {
    if (!url) return null;

    for (const [platform, patterns] of Object.entries(PLATFORM_PATTERNS)) {
        for (const pattern of patterns) {
            const match = url.match(pattern);
            if (match && match[1]) {
                return {
                    platform: platform as Platform,
                    id: match[1],
                };
            }
        }
    }

    return null;
}
