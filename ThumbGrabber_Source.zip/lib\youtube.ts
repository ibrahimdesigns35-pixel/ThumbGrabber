/**
 * YouTube Utility functions
 * Provides helper methods to extract video IDs and generate thumbnail URLs.
 */

/**
 * Parses a YouTube URL and returns the 11-character video ID.
 * Supports standard, shortened (youtu.be), embed, mobile, and share URLs.
 * @param url The YouTube URL to parse.
 * @returns The 11-character video ID or null if not found.
 */
export const extractVideoId = (url: string): string | null => {
    // Remove whitespace
    url = url.trim();

    // Support multiple URL patterns
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
        /youtube\.com\/watch\?.*v=([a-zA-Z0-9_-]{11})/,
        /^([a-zA-Z0-9_-]{11})$/, // Direct video ID
    ];

    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1] && match[1].length === 11) {
            return match[1];
        }
    }

    return null;
};

/**
 * Generates an array of YouTube thumbnail URLs for various resolutions.
 * @param videoId The 11-character YouTube video ID.
 * @returns An array of objects, each containing resolution, name, and URL for a thumbnail.
 */
export const getThumbnailUrls = (videoId: string) => {
    return [
        {
            resolution: '4K / Max Resolution',
            name: 'maxresdefault',
            url: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
        },
        {
            resolution: 'Full HD / Standard',
            name: 'sddefault',
            url: `https://img.youtube.com/vi/${videoId}/sddefault.jpg`,
        },
        {
            resolution: 'High Quality',
            name: 'hqdefault',
            url: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        },
        {
            resolution: 'Medium Quality',
            name: 'mqdefault',
            url: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
        },
        {
            resolution: 'Normal Quality',
            name: 'default',
            url: `https://img.youtube.com/vi/${videoId}/default.jpg`,
        },
    ];
};

export interface VideoInfo {
    title: string;
    author_name: string;
    thumbnail_url: string;
}

export const fetchVideoInfo = async (videoId: string): Promise<VideoInfo | null> => {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

        const response = await fetch(
            `https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v=${videoId}&format=json`,
            { signal: controller.signal }
        );

        clearTimeout(timeoutId);

        if (!response.ok) {
            console.error('YouTube API returned:', response.status);
            return null;
        }

        return await response.json();
    } catch (error) {
        if (error instanceof Error && error.name === 'AbortError') {
            console.error('Request timeout: YouTube API took too long to respond');
        } else {
            console.error('Error fetching video info:', error);
        }
        return null;
    }
};
