/**
 * TikTok Extractor
 * Extracts video cover images and metadata from TikTok
 */

import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout } from './base';

interface TikTokOEmbedResponse {
    title: string;
    author_name: string;
    author_unique_id: string;
    thumbnail_url: string;
}

export class TikTokExtractor implements Extractor {
    async extract(videoId: string): Promise<MediaInfo | null> {
        try {
            // TikTok oEmbed requires full URL
            const url = `https://www.tiktok.com/@user/video/${videoId}`;

            const response = await fetchWithTimeout(
                `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`
            );

            if (!response.ok) {
                throw new ExtractorError('Failed to fetch TikTok video', 'tiktok', 'FETCH_FAILED');
            }

            const data: TikTokOEmbedResponse = await response.json();

            const thumbnails: ThumbnailInfo[] = [
                {
                    url: data.thumbnail_url,
                    resolution: 'Cover Image',
                    available: true,
                },
            ];

            return {
                platform: 'tiktok',
                title: data.title || 'TikTok Video',
                creator_name: data.author_name || data.author_unique_id,
                thumbnail_url: data.thumbnail_url,
                thumbnails,
            };
        } catch (error) {
            if (error instanceof ExtractorError) {
                throw error;
            }
            console.error('TikTok extraction error:', error);
            return null;
        }
    }
}

export const tiktokExtractor = new TikTokExtractor();
