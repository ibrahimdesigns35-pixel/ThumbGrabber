/**
 * Twitter/X Extractor
 * Extracts tweet media previews and metadata
 */

import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout } from './base';

interface TwitterOEmbedResponse {
    author_name: string;
    author_url: string;
    html: string;
}

export class TwitterExtractor implements Extractor {
    async extract(tweetId: string): Promise<MediaInfo | null> {
        try {
            // Twitter oEmbed API
            const url = `https://twitter.com/user/status/${tweetId}`;

            const response = await fetchWithTimeout(
                `https://publish.twitter.com/oembed?url=${encodeURIComponent(url)}`
            );

            if (!response.ok) {
                throw new ExtractorError('Failed to fetch tweet', 'twitter', 'FETCH_FAILED');
            }

            const data: TwitterOEmbedResponse = await response.json();

            // Extract image from HTML if present
            const imageMatch = data.html.match(/<img[^>]+src="([^">]+)"/);
            const thumbnailUrl = imageMatch ? imageMatch[1] : this.getDefaultTwitterImage(tweetId);

            const thumbnails: ThumbnailInfo[] = [
                {
                    url: thumbnailUrl,
                    resolution: 'Tweet Preview',
                    available: true,
                },
            ];

            return {
                platform: 'twitter',
                title: 'Tweet',
                creator_name: data.author_name,
                thumbnail_url: thumbnailUrl,
                thumbnails,
            };
        } catch (error) {
            console.error('Twitter extraction error:', error);
            return null;
        }
    }

    private getDefaultTwitterImage(tweetId: string): string {
        // Fallback to Twitter card image format
        return `https://pbs.twimg.com/tweet_video_thumb/${tweetId}.jpg`;
    }
}

export const twitterExtractor = new TwitterExtractor();
