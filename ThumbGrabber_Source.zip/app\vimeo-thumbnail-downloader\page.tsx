import type { Metadata } from 'next';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LandingSections from '@/components/LandingSections';
import Footer from '@/components/Footer';
import { BreadcrumbSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "Vimeo Thumbnail Downloader - Download Vimeo Covers HD",
    description: "Download Vimeo video thumbnails and covers in high quality instantly. No signup. No tracking. 100% free and privacy-first.",
    keywords: ["vimeo thumbnail downloader", "download vimeo thumbnail", "vimeo cover downloader", "grab vimeo thumbnail"],
};

export default function VimeoDownloaderPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-20">
                {/* SEO Optimized Context */}
                <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-6">
                        Vimeo <span className="text-gradient">Thumbnail Downloader</span>
                    </h1>
                    <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-12">
                        Download high-definition Vimeo video thumbnails in original quality.
                        Enter any Vimeo URL below to grab the image instantly.
                    </p>
                </div>

                <Hero
                    isSubPage={true}
                    title="Download Vimeo Thumbnail"
                    subtitle="Original High Definition"
                />

                <LandingSections />
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Vimeo Thumbnail Downloader', url: '/vimeo-thumbnail-downloader' }
                ]}
            />

            <Footer />
        </div>
    );
}
