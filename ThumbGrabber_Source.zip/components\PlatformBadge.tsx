'use client';

import { Platform, PLATFORM_META } from '@/lib/platform-detector';
import { Youtube, Video, Music, Instagram, Linkedin, Twitter, Twitch, Facebook } from 'lucide-react';

interface PlatformBadgeProps {
    platform: Platform;
    size?: 'sm' | 'md' | 'lg';
    showName?: boolean;
}

const PLATFORM_ICONS = {
    youtube: Youtube,
    vimeo: Video,
    tiktok: Music,
    instagram: Instagram,
    linkedin: Linkedin,
    twitter: Twitter,
    twitch: Twitch,
    facebook: Facebook,
};

/**
 * PlatformBadge Component
 * Displays a platform icon and name with color-coded styling
 */
export default function PlatformBadge({ platform, size = 'md', showName = true }: PlatformBadgeProps) {
    const meta = PLATFORM_META[platform];
    const Icon = PLATFORM_ICONS[platform];

    if (!meta || !Icon) {
        return null;
    }

    const sizeClasses = {
        sm: 'px-2 py-1 text-xs gap-1',
        md: 'px-3 py-1.5 text-sm gap-2',
        lg: 'px-4 py-2 text-base gap-2',
    };

    const iconSizes = {
        sm: 'w-3 h-3',
        md: 'w-4 h-4',
        lg: 'w-5 h-5',
    };

    return (
        <div
            className={`inline-flex items-center ${sizeClasses[size]} rounded-full font-bold uppercase tracking-wider transition-all`}
            style={{
                backgroundColor: `${meta.color}15`,
                borderColor: `${meta.color}40`,
                color: meta.color,
                border: '1px solid',
            }}
        >
            <Icon className={iconSizes[size]} />
            {showName && <span>{meta.name}</span>}
        </div>
    );
}
