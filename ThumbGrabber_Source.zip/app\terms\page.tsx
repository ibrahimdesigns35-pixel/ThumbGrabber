import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function TermsPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow pt-32 pb-20 px-4">
                <div className="max-w-3xl mx-auto glass p-10 md:p-16 rounded-[3rem] border border-white/5 bg-slate-900/40">
                    <h1 className="text-4xl font-extrabold text-white mb-8 tracking-tight">Terms of Service</h1>
                    <div className="prose prose-invert max-w-none space-y-6 text-slate-300 font-medium leading-relaxed">
                        <p>
                            By using ThumbGrabber, you agree to the following terms and conditions. This tool is provided
                            "as is" for educational and personal use.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">1. Proper Usage</h2>
                        <p>
                            You agree to use ThumbGrabber only for lawful purposes. You are responsible for ensuring that your
                            use of extracted thumbnails complies with the copyright policies of the respective platforms (YouTube, Instagram, etc.).
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">2. IP Ownership</h2>
                        <p>
                            ThumbGrabber does not claim ownership of any content extracted using this tool. All trademarks,
                            video titles, and images belong to their respective creators and platforms.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">3. Disclaimer of Liability</h2>
                        <p>
                            ThumbGrabber is not affiliated with YouTube, Meta, or any other social platform. We are not responsible
                            for any misuse of this tool or for any content downloaded through it.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">4. Service Availability</h2>
                        <p>
                            This is a free tool provided without guarantees of uptime. We reserve the right to modify or discontinue
                            the service at any time without notice.
                        </p>

                        <div className="mt-12 p-6 rounded-2xl bg-slate-500/10 border border-slate-500/20 text-slate-400 text-sm">
                            Last Updated: February 2026
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
