import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function PrivacyPage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow pt-32 pb-20 px-4">
                <div className="max-w-3xl mx-auto glass p-10 md:p-16 rounded-[3rem] border border-white/5 bg-slate-900/40">
                    <h1 className="text-4xl font-extrabold text-white mb-8 tracking-tight">Privacy Policy</h1>
                    <div className="prose prose-invert max-w-none space-y-6 text-slate-300 font-medium leading-relaxed">
                        <p>
                            At ThumbGrabber, we take your privacy seriously. This project is built on the principle of
                            <strong> zero-tracking</strong> and <strong>zero-data retention</strong>.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">1. No Personal Data Collection</h2>
                        <p>
                            We do not collect any personal information, such as your IP address, browser type, or search history.
                            There is no login system, and no cookies are used for tracking.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">2. No Media Storage</h2>
                        <p>
                            ThumbGrabber does not store the URLs you paste or the thumbnails you download. All extractions happen in
                            real-time via platform APIs and are served directly to your browser.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">3. Third-Party Services</h2>
                        <p>
                            We interact with public APIs from YouTube, Vimeo, and other platforms to fetch thumbnail metadata.
                            While we don't track you, those platforms may have their own privacy policies.
                        </p>

                        <h2 className="text-2xl font-bold text-white mt-10">4. Open Source</h2>
                        <p>
                            As a commitment to transparency, our codebase is designed with privacy-first logic that anyone
                            can audit. We use no databases or persistent storage layers.
                        </p>

                        <div className="mt-12 p-6 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm">
                            Last Updated: February 2026
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
