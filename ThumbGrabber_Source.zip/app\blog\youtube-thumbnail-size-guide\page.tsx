import type { Metadata } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { BreadcrumbSchema, FAQSchema } from '@/components/SEOComponents';

export const metadata: Metadata = {
    title: "YouTube Thumbnail Size Guide 2026: Best Dimensions & Resolution",
    description: "Learn the perfect YouTube thumbnail size, aspect ratio, and resolution for 2026. Get more clicks with HD thumbnails.",
    keywords: ["youtube thumbnail size", "youtube thumbnail dimensions", "youtube thumbnail resolution", "best size for youtube thumbnail"],
};

export default function SizeGuidePage() {
    return (
        <div className="flex flex-col min-h-screen">
            <Header />

            <main className="flex-grow pt-32 pb-20 px-4">
                <article className="max-w-4xl mx-auto prose prose-invert prose-blue">
                    <h1 className="text-4xl md:text-6xl font-black text-white mb-8">
                        YouTube <span className="text-gradient">Thumbnail Size Guide</span> (2026)
                    </h1>

                    <p className="text-slate-400 text-lg mb-8">
                        Creating a great video is only half the battle. To get people to click, you need a high-quality thumbnail.
                        But what is the correct YouTube thumbnail size? In this guide, we'll break down everything you need to know.
                    </p>

                    <h2 className="text-2xl font-bold text-white mb-4">Recommended YouTube Thumbnail Dimensions</h2>
                    <p>
                        According to YouTube, the best thumbnail size is <strong>1280 x 720 pixels</strong>.
                        While your thumbnail will also be used in smaller sizes across the site, this high-resolution ensures it looks sharp on all devices.
                    </p>

                    <div className="my-10 overflow-x-auto glass rounded-2xl p-6">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="border-b border-white/10">
                                    <th className="py-4 px-2 text-blue-400">Spec</th>
                                    <th className="py-4 px-2 text-blue-400">Recommendation</th>
                                </tr>
                            </thead>
                            <tbody className="text-slate-300">
                                <tr className="border-b border-white/5">
                                    <td className="py-4 px-2 font-bold">Ideal Width</td>
                                    <td className="py-4 px-2">1280 Pixels</td>
                                </tr>
                                <tr className="border-b border-white/5">
                                    <td className="py-4 px-2 font-bold">Ideal Height</td>
                                    <td className="py-4 px-2">720 Pixels</td>
                                </tr>
                                <tr className="border-b border-white/5">
                                    <td className="py-4 px-2 font-bold">Minimum Width</td>
                                    <td className="py-4 px-2">640 Pixels</td>
                                </tr>
                                <tr className="border-b border-white/5">
                                    <td className="py-4 px-2 font-bold">Aspect Ratio</td>
                                    <td className="py-4 px-2">16:9</td>
                                </tr>
                                <tr className="border-b border-white/5">
                                    <td className="py-4 px-2 font-bold">File Formats</td>
                                    <td className="py-4 px-2">JPG, GIF, PNG</td>
                                </tr>
                                <tr>
                                    <td className="py-4 px-2 font-bold">Max File Size</td>
                                    <td className="py-4 px-2">2MB</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <h2 className="text-2xl font-bold text-white mb-4">Why 1280x720?</h2>
                    <p>
                        Even though thumbnails appear small in search results, they are also used as the preview image when your video is embedded on other sites.
                        If you use a low-resolution image, it will look pixelated and unprofessional.
                    </p>

                    <div className="bg-blue-500/10 border border-blue-500/20 p-8 rounded-3xl my-10">
                        <h3 className="text-xl font-bold text-blue-400 mb-2">Pro Tip: Use Our Tool!</h3>
                        <p className="text-slate-300 mb-4">
                            Need a high-res thumbnail from an existing video? Use our
                            <Link href="/youtube-thumbnail-downloader" className="text-white underline ml-1">
                                YouTube Thumbnail Downloader
                            </Link>
                            to grab the maximum quality image instantly.
                        </p>
                    </div>

                    <h2 className="text-2xl font-bold text-white mb-8 text-center">Frequently Asked Questions</h2>
                    <div className="space-y-6 mb-12">
                        <div className="glass p-6 rounded-2xl">
                            <h4 className="font-bold text-white mb-2">Can I use a 1920x1080 image?</h4>
                            <p className="text-sm text-slate-400">Yes, as long as it stays under the 2MB limit. YouTube will scale it down appropriately.</p>
                        </div>
                        <div className="glass p-6 rounded-2xl">
                            <h4 className="font-bold text-white mb-2">What happens if my aspect ratio is wrong?</h4>
                            <p className="text-sm text-slate-400">YouTube will add black bars to the sides or top of your thumbnail to make it fit the 16:9 player.</p>
                        </div>
                    </div>
                </article>
            </main>

            <BreadcrumbSchema
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Blog', url: '/blog' },
                    { name: 'YouTube Thumbnail Size Guide', url: '/blog/youtube-thumbnail-size-guide' }
                ]}
            />
            <FAQSchema
                faqs={[
                    {
                        question: "Can I use a 1920x1080 image for YouTube thumbnails?",
                        answer: "Yes, as long as it stays under the 2MB limit. YouTube will scale it down appropriately to 720p."
                    },
                    {
                        question: "What happens if my thumbnail aspect ratio is wrong?",
                        answer: "YouTube will add black bars to the sides or top of your thumbnail to make it fit the 16:9 player."
                    }
                ]}
            />

            <Footer />
        </div>
    );
}
