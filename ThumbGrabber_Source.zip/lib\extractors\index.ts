/**
 * Extractor Factory
 * Central hub for managing all platform extractors
 * WITH SAFETY CHECKS - Only working extractors enabled
 */

import { Platform } from '../platform-detector';
import { Extractor, MediaInfo, ExtractorError } from './base';
import { youtubeExtractor } from './youtube';
import { vimeoExtractor } from './vimeo';
// Unsupported extractors commented out until implemented
// import { tiktokExtractor } from './tiktok';
// import { instagramExtractor } from './instagram';
// import { linkedinExtractor } from './linkedin';
// import { twitterExtractor } from './twitter';
// import { twitchExtractor } from './twitch';
// import { facebookExtractor } from './facebook';

/**
 * Map of platform to extractor instance
 * ONLY WORKING EXTRACTORS ARE ENABLED
 */
const extractors: Partial<Record<Platform, Extractor>> = {
    youtube: youtubeExtractor,
    vimeo: vimeoExtractor, // Partial support
    // Others will be added as they are implemented and tested
};

/**
 * Gets the appropriate extractor for a platform
 * @param platform - The platform identifier
 * @returns Extractor instance or null if not available
 */
export function getExtractor(platform: Platform): Extractor | null {
    return extractors[platform] || null;
}

/**
 * Extracts media information using the appropriate platform extractor
 * WITH SAFETY CHECKS
 * @param platform - The platform identifier
 * @param id - Platform-specific media ID
 * @returns MediaInfo object or null if extraction fails
 */
export async function extractMedia(platform: Platform, id: string): Promise<MediaInfo | null> {
    const extractor = getExtractor(platform);

    if (!extractor) {
        throw new ExtractorError(
            'Platform not yet supported',
            platform,
            'UNSUPPORTED'
        );
    }

    try {
        return await extractor.extract(id);
    } catch (error) {
        console.error(`Extraction failed for ${platform}:`, error);
        return null;
    }
}

// Export working extractors
export {
    youtubeExtractor,
    vimeoExtractor,
};
