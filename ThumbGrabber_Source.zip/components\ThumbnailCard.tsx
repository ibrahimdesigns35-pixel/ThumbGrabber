'use client';

import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Check, AlertCircle, Maximize2, Loader2 } from 'lucide-react';
import { useState } from 'react';

interface ThumbnailCardProps {
    url: string;
    resolution: string;
    videoTitle: string;
    channelName: string;
    platform: string;
}

/**
 * ThumbnailCard Component - Premium Download Experience
 */
export default function ThumbnailCard({ url, resolution, videoTitle, channelName, platform }: ThumbnailCardProps) {
    const [downloadState, setDownloadState] = useState<'idle' | 'preparing' | 'downloading' | 'success' | 'error'>('idle');
    const [hasError, setHasError] = useState(false);

    // Honest labeling for YouTube
    const refinedResolution = platform === 'youtube' && resolution.includes('maxresdefault')
        ? 'Original Quality (1280x720)'
        : resolution;

    const handleDownload = async () => {
        if (downloadState !== 'idle') return;

        try {
            setDownloadState('preparing');

            // Simulate preparation delay for premium feel
            await new Promise(resolve => setTimeout(resolve, 800));

            setDownloadState('downloading');

            const response = await fetch(url);
            if (!response.ok) throw new Error("Could not fetch image");

            const blob = await response.blob();
            const blobUrl = window.URL.createObjectURL(blob);

            const link = document.createElement("a");
            link.href = blobUrl;
            link.download = `ThumbGrabber-${videoTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase()}-${platform}.jpg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            window.URL.revokeObjectURL(blobUrl);

            setDownloadState('success');
            setTimeout(() => setDownloadState('idle'), 3000);
        } catch (error) {
            console.error("Download failed:", error);
            setDownloadState('error');
            setTimeout(() => setDownloadState('idle'), 3000);
        }
    };

    if (hasError) return null;

    return (
        <motion.div
            whileHover={{ y: -8 }}
            className="glass rounded-3xl overflow-hidden group border border-white/5 bg-slate-900/40"
        >
            <div className="relative aspect-video w-full overflow-hidden">
                <Image
                    src={url}
                    alt={resolution}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    onError={() => setHasError(true)}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

                <motion.div
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="absolute top-4 right-4 p-2 glass rounded-xl opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer hover:bg-white/10"
                    onClick={() => window.open(url, '_blank')}
                >
                    <Maximize2 className="w-4 h-4 text-white" />
                </motion.div>

                {/* Resolution Badge */}
                <div className="absolute bottom-4 left-4 flex gap-2">
                    <span className="px-2 py-1 bg-black/50 backdrop-blur-md rounded-md text-[10px] font-bold text-white uppercase tracking-wider">
                        {platform}
                    </span>
                    {resolution.includes('maxresdefault') && (
                        <span className="px-2 py-1 bg-blue-500/50 backdrop-blur-md rounded-md text-[10px] font-bold text-white uppercase tracking-wider">
                            Original
                        </span>
                    )}
                </div>
            </div>

            <div className="p-6 flex flex-col gap-5">
                <div>
                    <h3 className="font-bold text-lg text-white leading-tight mb-1 truncate">
                        {refinedResolution}
                    </h3>
                    <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest">
                        {platform === 'youtube' ? 'High definition available' : 'Original extraction quality'}
                    </p>
                </div>

                <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleDownload}
                    disabled={downloadState !== 'idle'}
                    className={`relative w-full py-4 px-4 rounded-2xl flex items-center justify-center gap-2 font-bold transition-all duration-300 overflow-hidden ${downloadState === 'error'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                        : downloadState === 'success'
                            ? 'bg-green-500/20 text-green-400 border border-green-500/50'
                            : 'accent-gradient text-white hover:shadow-[0_0_20px_rgba(59,130,246,0.3)]'
                        } disabled:opacity-80 cursor-pointer`}
                >
                    {/* Premium Pulse Effect */}
                    {downloadState === 'idle' && (
                        <motion.div
                            animate={{
                                scale: [1, 1.05, 1],
                                opacity: [0.3, 0.1, 0.3],
                            }}
                            transition={{
                                duration: 2,
                                repeat: Infinity,
                                ease: "easeInOut"
                            }}
                            className="absolute inset-0 bg-white/10 pointer-events-none"
                        />
                    )}

                    {/* Shimmer Effect during prepare/download */}
                    {(downloadState === 'preparing' || downloadState === 'downloading') && (
                        <div className="absolute inset-0 shimmer-bg opacity-30" />
                    )}

                    <AnimatePresence mode="wait">
                        {downloadState === 'idle' && (
                            <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
                                <Download className="w-5 h-5" />
                                <span>DOWNLOAD NOW</span>
                            </motion.div>
                        )}
                        {downloadState === 'preparing' && (
                            <motion.div key="preparing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
                                <Loader2 className="w-5 h-5 animate-spin" />
                                <span>PREPARING...</span>
                            </motion.div>
                        )}
                        {downloadState === 'downloading' && (
                            <motion.div key="downloading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
                                <Loader2 className="w-5 h-5 animate-spin" />
                                <span>DOWNLOADING...</span>
                            </motion.div>
                        )}
                        {downloadState === 'success' && (
                            <motion.div key="success" initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2 text-green-400">
                                <Check className="w-6 h-6" />
                                <span>SAVED!</span>
                            </motion.div>
                        )}
                        {downloadState === 'error' && (
                            <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2 text-red-400">
                                <AlertCircle className="w-5 h-5" />
                                <span>FAILED</span>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </motion.button>
            </div>
        </motion.div>
    );
}
