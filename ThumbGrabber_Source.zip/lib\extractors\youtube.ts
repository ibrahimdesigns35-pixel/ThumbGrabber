import { Extractor, MediaInfo, ThumbnailInfo, ExtractorError, fetchWithTimeout, checkUrlAvailability } from './base';

interface YouTubeOEmbedResponse {
    title: string;
    author_name: string;
    thumbnail_url: string;
}

/**
 * YouTube Extractor - Reliable Fallbacks & Honest Labeling
 * Final Production Version
 */
export class YouTubeExtractor implements Extractor {
    private readonly THUMBNAIL_FORMATS = [
        { name: 'maxresdefault', resolution: 'Original Quality (1280x720)' },
        { name: 'sddefault', resolution: 'Standard HD (640x480)' },
        { name: 'hqdefault', resolution: 'High Quality (480x360)' },
        { name: 'mqdefault', resolution: 'Medium Quality (320x180)' },
        { name: 'default', resolution: 'Normal Quality (120x90)' },
    ];

    async extract(videoId: string): Promise<MediaInfo | null> {
        try {
            const info = await this.fetchVideoInfo(videoId);
            if (!info) return null;

            const thumbnails = await this.generateOptimizedThumbnails(videoId);

            return {
                platform: 'youtube',
                title: info.title,
                creator_name: info.author_name,
                thumbnail_url: thumbnails[0]?.url || `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
                thumbnails: thumbnails
            };
        } catch (error) {
            console.error('YouTube extraction failed:', error);
            throw new ExtractorError('Failed to extract YouTube video info', 'youtube');
        }
    }

    private async fetchVideoInfo(videoId: string): Promise<YouTubeOEmbedResponse | null> {
        try {
            const response = await fetchWithTimeout(
                `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
            );

            if (response.status === 404) return null;
            if (!response.ok) throw new Error('OEmbed request failed');

            return await response.json();
        } catch (error) {
            console.warn(`OEmbed fetch failed for ${videoId}, using skeleton fallback.`);
            return {
                title: 'YouTube Video',
                author_name: 'Creator',
                thumbnail_url: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
            };
        }
    }

    /**
     * Generates a list of thumbnails, checking availability for the highest quality.
     */
    private async generateOptimizedThumbnails(videoId: string): Promise<ThumbnailInfo[]> {
        const results: ThumbnailInfo[] = [];

        // Always check maxresdefault availability as it often fails
        const maxResUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
        const isMaxResAvailable = await checkUrlAvailability(maxResUrl);

        for (const format of this.THUMBNAIL_FORMATS) {
            const url = `https://img.youtube.com/vi/${videoId}/${format.name}.jpg`;

            if (format.name === 'maxresdefault') {
                if (isMaxResAvailable) {
                    results.push({
                        url,
                        resolution: format.resolution,
                        available: true
                    });
                }
                continue;
            }

            // Other formats are almost always available if the video exists
            results.push({
                url,
                resolution: format.resolution,
                available: true
            });
        }

        return results;
    }
}

export const youtubeExtractor = new YouTubeExtractor();
