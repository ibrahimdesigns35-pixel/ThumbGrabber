'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ShieldCheck, Github } from 'lucide-react';
import Logo from './Logo';

/**
 * Header Component - Zero Dead Links
 */
export default function Header() {
    return (
        <motion.header
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className="fixed top-0 left-0 right-0 z-50 px-4 py-6 pointer-events-none"
        >
            <div className="max-w-7xl mx-auto flex items-center justify-between glass px-6 md:px-10 py-4 rounded-[2rem] pointer-events-auto border border-white/5 bg-slate-900/40 backdrop-blur-2xl">
                <Link href="/" className="pointer-events-auto">
                    <Logo />
                </Link>

                <nav className="hidden lg:flex items-center gap-10">
                    <Link href="/#how-it-works" className="text-sm font-bold text-slate-400 hover:text-white transition-colors">How it works</Link>
                    <Link href="/#features" className="text-sm font-bold text-slate-400 hover:text-white transition-colors">Features</Link>
                    <Link href="/youtube-thumbnail-downloader" className="text-sm font-bold text-slate-400 hover:text-white transition-colors relative group">
                        YouTube HD
                        <span className="absolute -top-4 -right-2 px-1.5 py-0.5 bg-blue-500/20 text-blue-400 text-[8px] font-black uppercase rounded-md border border-blue-500/20">Active</span>
                    </Link>
                </nav>

                <div className="flex items-center gap-4">
                    <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-green-500/10 text-green-400 text-[10px] font-black uppercase tracking-[0.2em] rounded-full border border-green-500/20">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Privacy-First</span>
                    </div>
                    <motion.a
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        href="https://github.com"
                        target="_blank"
                        className="px-6 py-2.5 glass text-white text-xs font-bold rounded-2xl hover:bg-white/10 transition-all border border-white/10"
                    >
                        GITHUB
                    </motion.a>
                </div>
            </div>
        </motion.header>
    );
}
