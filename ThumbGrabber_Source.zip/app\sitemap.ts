import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
    const baseUrl = 'https://thumbgrabber-official.vercel.app';
    const platforms = [
        'youtube-thumbnail-downloader',
        'tiktok-thumbnail-downloader',
        'instagram-thumbnail-downloader',
        'facebook-thumbnail-downloader',
        'twitter-x-thumbnail-downloader',
        'vimeo-thumbnail-downloader'
    ];

    const blogPosts = [
        'youtube-thumbnail-size-guide',
        'how-to-download-youtube-thumbnail'
    ];

    const platformUrls = platforms.map((p) => ({
        url: `${baseUrl}/${p}`,
        lastModified: new Date(),
        changeFrequency: 'weekly' as const,
        priority: 0.8,
    }));

    const blogUrls = blogPosts.map((b) => ({
        url: `${baseUrl}/blog/${b}`,
        lastModified: new Date(),
        changeFrequency: 'monthly' as const,
        priority: 0.6,
    }));

    return [
        {
            url: baseUrl,
            lastModified: new Date(),
            changeFrequency: 'daily' as const,
            priority: 1,
        },
        ...platformUrls,
        ...blogUrls,
    ];
}
